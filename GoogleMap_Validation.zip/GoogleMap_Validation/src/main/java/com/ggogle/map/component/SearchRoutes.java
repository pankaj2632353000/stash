package com.ggogle.map.component;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.google.map.base.BaseTest;
import com.thoughtworks.selenium.Wait;

public class SearchRoutes extends BaseTest {

	WebDriver driver;
	
	@FindBy(xpath="//input[@id='searchboxinput']")
	public WebElement searchlocation;
	@FindBy(id="searchbox-searchbutton")
	 WebElement searchlocationBtn;
	@FindBy(xpath="//input[contains(@placeholder,'starting')]")
	 WebElement searchlocationSource;
	@FindBy(xpath="//input[contains(@placeholder,'destination')]")
	 WebElement searchlocationDestination;
	@FindBy(xpath="//*[@id='directions-searchbox-1']/button[1]")
	 WebElement searchlocationbtn;
	@FindBy(xpath="//img[@aria-label='Driving']")
	 WebElement driving;
	@FindAll({
	@FindBy(xpath="//div[@class='section-layout']/div")
	})
	private List<WebElement> listpfroutes;
	@FindAll({
	@FindBy(xpath="//div[contains(@id,'section-directions-trip')]")
	})
	private List<WebElement> listofRoutesDisplay;
	@FindBy(xpath="//div[@class='section-directions-trip-duration delay-light']/span[1]")
	 public WebElement time;
	@FindBy(xpath="//div[@class='section-directions-trip-distance section-directions-trip-secondary-text']/span[2]/following::div[1]")
	 public WebElement miles;
	@FindBy(xpath="//h1[@id='section-directions-trip-title-0']/span")
	 public WebElement routestitle;
	
	@FindBy(xpath="//a[@tooltip='Clear search']")
	 public WebElement cleanSourceinputtxt;
	
	@FindBy(xpath="//button[@aria-label='Directions']")
	 public WebElement directions;
	
	
	
	public SearchRoutes(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void navigateToSanFrancisco() throws InterruptedException{
		explicitWait(searchlocationBtn, 30);
		searchlocation.sendKeys("San Francisco, California");
		/*JavascriptExecutor js = (JavascriptExecutor)driver;
		  js.executeScript("document.getElementById('searchboxinput').value='San Francisco, California';");
	*/	searchlocationBtn.click();
	   Thread.sleep(5000);
	}
	
	public void navigateToChico_SanFrancisco() throws InterruptedException{
		explicitWait(cleanSourceinputtxt, 5);
		cleanSourceinputtxt.click();
		directions.click();
		explicitWait(searchlocationSource, 10);
		searchlocationSource.sendKeys("Chico, California");
		explicitWait(searchlocationDestination, 10);
		searchlocationDestination.sendKeys("San Francisco, California");
		searchlocationbtn.click();
		driving.click();

	} 
	  
	public int listofRoutes(){
		int numberOfRoutes=listpfroutes.size();
		return numberOfRoutes;
	} 
	
	public int listRoutes(){
		int number_Routes=listofRoutesDisplay.size();
		return number_Routes;
	}
	    
	
	
	public String displaytime(){
		String displayTime=time.getText();
       return displayTime;

	}
	public String displayMiles(){
		String displaymiles=miles.getText();
	       return displaymiles;

	}
	public String displayTitle(){
		String displayTitle=routestitle.getText();
	       return displayTitle;

	}
	 	
 public void explicitWait(WebElement web,int time){
	WebDriverWait wait = new WebDriverWait(driver,time);
	wait.until(ExpectedConditions.visibilityOf(web));
}
 public void waitforPagetoLoad(int time){
	 WebDriverWait wait = new WebDriverWait(driver, 30);
	    wait.until(new Function<WebDriver, Boolean>() {
	        public Boolean apply(WebDriver driver) {
	            System.out.println("Current Window State:"+ String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));
	            return String
	                .valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
	                .equals("complete");
	        }
	    });

 }
 public void closeBrowser(){
	driver.close();
}
}
