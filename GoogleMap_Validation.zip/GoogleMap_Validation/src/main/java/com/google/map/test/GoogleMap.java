package com.google.map.test;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ggogle.map.component.SearchRoutes;
import com.google.map.base.BaseTest;
import com.google.map.base.RoutesTimeMilesTitle;

public class GoogleMap extends BaseTest {
	WebDriver driver;

	@Test
	public void navigateGoogleMap_Search() throws IOException, InterruptedException {
		// Scenario2/3/4/5/6/7
		driver=navigateToURL();
		driver.navigate().to("https://maps.google.com/");
		SearchRoutes searchRoutes = new SearchRoutes(driver);
		searchRoutes.navigateToSanFrancisco();
		String currentURL = driver.getCurrentUrl();
		searchRoutes.waitforPagetoLoad(10);
		Assert.assertTrue(currentURL.contains("37.7576793"),"Data not found");
		searchRoutes.navigateToChico_SanFrancisco();
		Assert.assertEquals(searchRoutes.listofRoutes(), searchRoutes.listRoutes());
		RoutesTimeMilesTitle.createfile();
		searchRoutes.explicitWait(searchRoutes.routestitle, 10);
		RoutesTimeMilesTitle.writeData(searchRoutes.displayTitle(),searchRoutes.displayMiles(),searchRoutes.displaytime());
		searchRoutes.closeBrowser();
	}
}
