package com.google.map.base;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class RoutesTimeMilesTitle {

	public static void createfile() {
		File file = new File("routes.txt");
		try {
			boolean result = file.createNewFile();
			if (result) {
				System.out.println("file created " + file.getCanonicalPath());
			} else {
				System.out.println("File already exist at location: " + file.getCanonicalPath());
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void writeData(String title,String miles,String times) throws IOException {
		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("routes.txt")));
		writer.write(title);
		writer.write("\r\n");
		writer.write(miles);
		writer.write("\r\n");
		writer.write(times);
		writer.close();

	}
}
